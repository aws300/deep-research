from deepresearch.dedupe_lambda import lambda_handler  # noqa: F401
