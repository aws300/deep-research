from deepresearch.mcp_tools_lambda import lambda_handler  # noqa: F401
